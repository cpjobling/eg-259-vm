-- phpMyAdmin SQL Dump
-- version 2.9.0.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Nov 23, 2006 at 10:59 AM
-- Server version: 5.0.24
-- PHP Version: 5.1.6
-- 
-- Database: `cars`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `Corvettes_Equipment`
-- 

DROP TABLE IF EXISTS `Corvettes_Equipment`;

CREATE TABLE `Corvettes_Equipment` (
  `Vette_id` int(11) NOT NULL,
  `Equip` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `Corvettes_Equipment`
-- 

INSERT INTO `Corvettes_Equipment` VALUES (1, 1);
INSERT INTO `Corvettes_Equipment` VALUES (1, 5);
INSERT INTO `Corvettes_Equipment` VALUES (1, 6);
INSERT INTO `Corvettes_Equipment` VALUES (2, 1);
INSERT INTO `Corvettes_Equipment` VALUES (2, 5);
INSERT INTO `Corvettes_Equipment` VALUES (2, 6);
INSERT INTO `Corvettes_Equipment` VALUES (3, 1);
INSERT INTO `Corvettes_Equipment` VALUES (3, 6);
INSERT INTO `Corvettes_Equipment` VALUES (4, 2);
INSERT INTO `Corvettes_Equipment` VALUES (4, 6);
INSERT INTO `Corvettes_Equipment` VALUES (5, 1);
INSERT INTO `Corvettes_Equipment` VALUES (5, 6);
INSERT INTO `Corvettes_Equipment` VALUES (6, 2);
INSERT INTO `Corvettes_Equipment` VALUES (7, 4);
INSERT INTO `Corvettes_Equipment` VALUES (7, 6);
INSERT INTO `Corvettes_Equipment` VALUES (8, 4);
INSERT INTO `Corvettes_Equipment` VALUES (8, 5);
INSERT INTO `Corvettes_Equipment` VALUES (8, 6);
INSERT INTO `Corvettes_Equipment` VALUES (9, 4);
INSERT INTO `Corvettes_Equipment` VALUES (9, 5);
INSERT INTO `Corvettes_Equipment` VALUES (9, 6);
INSERT INTO `Corvettes_Equipment` VALUES (10, 1);
INSERT INTO `Corvettes_Equipment` VALUES (10, 5);


